package com.example.newproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerview.ExampleAdapter
import java.util.*
import kotlin.collections.ArrayList
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private val exampleList = ArrayList<ProjectExampleItem>()
    private val adapter = ExampleAdapter(exampleList)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler_view = findViewById<RecyclerView>(R.id.recycler_view)

        recycler_view.adapter = adapter
        recycler_view.layoutManager = LinearLayoutManager (this)
        recycler_view.setHasFixedSize(true)
    }

    fun insertitem(view: View) {

        val mensagem = findViewById<EditText>(R.id.mensagem)

        if (mensagem.text.isEmpty()) {
            Toast.makeText(this, "Insira uma mensagem.", Toast.LENGTH_SHORT).show()
        } else {
            val newitem = ProjectExampleItem(
                R.drawable.ic_android,
                mensagem.text.toString(),
                Date().toString()
            )

            exampleList.add(0, newitem)
            adapter.notifyItemInserted(0)
            mensagem.text.clear()
        }
    }

}