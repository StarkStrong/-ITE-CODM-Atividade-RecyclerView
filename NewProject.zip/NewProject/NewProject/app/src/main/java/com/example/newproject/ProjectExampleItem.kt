package com.example.newproject

data class ProjectExampleItem(val imageResource: Int, val text1: String, val text2: String)